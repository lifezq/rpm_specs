/**
* PACKAGE ${GO_PACKAGE_NAME}
* Name ${NAME}
* Description TODO
* Author yangqianlei@deltaphone.com.cn
* Date ${DATE}
 */
package main

func main() {
	#[[$END$]]#
}
