# 常用模式和标准

## 错误处理模式

### Go
```go
if err != nil {
    return fmt.Errorf("操作失败: %w", err)
}
```

### JavaScript/TypeScript  
```typescript
type Result<T, E = Error> = { success: true; data: T } | { success: false; error: E };
```

### Python
```python
from typing import Optional, Union
def operation() -> Union[Result, Error]:
    try:
        # 操作逻辑
        return result
    except Exception as e:
        logger.error(f"操作失败: {e}")
        raise
```

## 性能优化模式

### 数据库
- 在查询字段上使用索引
- 尽可能批量操作
- 实现连接池
- 缓存频繁查询

### 前端
- 大数据集延迟加载
- 用户输入防抖
- 昂贵计算记忆化
- 列表虚拟滚动

### API设计
- 大数据集分页
- 限流
- 响应缓存头
- 高效序列化

## 安全模式

### 输入验证
```typescript
const schema = z.object({
  email: z.string().email(),
  password: z.string().min(8)
});
```

### 身份认证
- 短过期时间的JWT
- 刷新令牌轮换
- 认证端点限流
- 安全会话管理

## 测试模式

### 单元测试结构
```javascript
describe('组件', () => {
  it('应该处理边界情况', () => {
    // 准备
    const input = setupTestData();
    
    // 执行
    const result = component.method(input);
    
    // 断言
    expect(result).toEqual(expectedOutput);
  });
});
```

### 集成测试重点
- API契约合规性
- 数据库事务
- 外部服务模拟
- 错误边界测试

## 架构决策

### 微服务
**适用场景**：独立扩展，团队自治
**避免场景**：简单应用，共享事务

### 单体架构
**适用场景**：单个团队，共享数据模型
**重构时机**：部署瓶颈，扩展冲突

### 事件驱动
**适用场景**：松散耦合，异步处理
**复杂度**：消息顺序，重复处理

## 代码组织

### 项目结构
```
/src
  /core       # 业务逻辑
  /api        # HTTP处理器
  /data       # 数据库/存储
  /config     # 配置
  /tests      # 测试工具
```

### 命名约定
- 函数/方法：动词+名词 (`getUserById`)
- 类：名词 (`UserService`)
- 常量：SCREAMING_SNAKE_CASE
- 文件：web用kebab-case，Python用snake_case