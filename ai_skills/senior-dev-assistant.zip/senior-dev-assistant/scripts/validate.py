#!/usr/bin/env python3
"""
验证高级开发工程师助手技能配置
使用方法: python scripts/validate.py
"""

import os
import yaml
import sys
from pathlib import Path

def validate_skill():
    """验证技能配置和结构"""
    
    skill_dir = Path(__file__).parent.parent
    skill_file = skill_dir / "SKILL.md"
    
    print("🔍 正在验证高级开发工程师助手技能...")
    print(f"📁 技能目录: {skill_dir}")
    
    # 检查SKILL.md是否存在
    if not skill_file.exists():
        print("❌ 未找到SKILL.md文件")
        return False
    
    # 读取并解析前置信息
    try:
        with open(skill_file, 'r', encoding='utf-8') as f:
            content = f.read()
            
        # 提取前置信息
        if not content.startswith('---'):
            print("❌ 未找到YAML前置信息")
            return False
            
        parts = content.split('---', 2)
        if len(parts) < 3:
            print("❌ 前置信息格式无效")
            return False
            
        frontmatter = yaml.safe_load(parts[1])
        body = parts[2].strip()
        
    except Exception as e:
        print(f"❌ 读取SKILL.md时出错: {e}")
        return False
    
    # 验证前置信息字段
    required_fields = ['name', 'description']
    for field in required_fields:
        if field not in frontmatter:
            print(f"❌ 缺少必需字段: {field}")
            return False
    
    # 验证名称格式
    name = frontmatter['name']
    if not name.replace('-', '').replace('_', '').isalnum():
        print(f"❌ 名称格式无效: {name}")
        return False
    
    if len(name) > 64:
        print(f"❌ 名称过长: {len(name)} 字符 (最大64)")
        return False
    
    # 验证描述
    description = frontmatter['description']
    if len(description) > 1024:
        print(f"❌ 描述过长: {len(description)} 字符 (最大1024)")
        return False
    
    if not description.strip():
        print("❌ 描述为空")
        return False
    
    # 检查正文长度
    body_lines = len(body.split('\n'))
    if body_lines > 500:
        print(f"⚠️  正文可能过长: {body_lines} 行 (建议: <500行)")
    
    # 检查支持文件
    patterns_file = skill_dir / "patterns.md"
    reference_file = skill_dir / "quick-reference.md"
    
    supporting_files = []
    if patterns_file.exists():
        supporting_files.append("patterns.md")
    if reference_file.exists():
        supporting_files.append("quick-reference.md")
    
    print("\n✅ 技能验证通过!")
    print(f"📝 名称: {name}")
    print(f"📄 描述: {description[:100]}{'...' if len(description) > 100 else ''}")
    print(f"📏 正文长度: {body_lines} 行")
    
    if supporting_files:
        print(f"📚 支持文件: {', '.join(supporting_files)}")
    
    # 检查技能是否在正确位置
    expected_path = Path.home() / ".cursor" / "skills" / name
    if skill_dir == expected_path:
        print(f"📍 位置: 个人技能 (正确)")
    else:
        print(f"📍 位置: {skill_dir}")
        if "/.cursor/skills/" in str(skill_dir):
            print("✅ 在Cursor技能目录中")
        else:
            print("⚠️  不在标准Cursor技能目录中")
    
    return True

def check_cursor_integration():
    """检查Cursor是否能发现此技能"""
    
    print("\n🔧 检查Cursor集成...")
    
    # 检查.cursor目录是否存在
    cursor_dir = Path.home() / ".cursor"
    if not cursor_dir.exists():
        print("⚠️  未找到~/.cursor目录")
        print("💡 首次使用Cursor时会创建此技能")
        return
    
    skills_dir = cursor_dir / "skills"
    if not skills_dir.exists():
        print("⚠️  未找到~/.cursor/skills目录")
        print("💡 创建此目录来存储个人技能")
        return
    
    print("✅ 找到Cursor目录")
    print("💡 如需要，请重启Cursor以重新加载技能")

def main():
    """主验证函数"""
    
    print("🤖 高级开发工程师助手技能验证器\n")
    
    success = validate_skill()
    
    if success:
        check_cursor_integration()
        print("\n🎉 验证完成！技能已准备就绪。")
        print("\n💡 使用此技能的技巧:")
        print("   - 说'代码审查'或'审查代码'来触发代码分析")
        print("   - 说'优化这个'来获得性能改进建议")  
        print("   - 说'调试'或'修复'来进行问题解决")
        print("   - 说'实现X功能'来获得直接解决方案")
    else:
        print("\n❌ 技能验证失败")
        sys.exit(1)

if __name__ == "__main__":
    main()