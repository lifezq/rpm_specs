# 快速参考

## 常用代码片段

### HTTP客户端 (Go)
```go
client := &http.Client{Timeout: 30 * time.Second}
req, _ := http.NewRequest("GET", url, nil)
req.Header.Set("Authorization", "Bearer "+token)
resp, err := client.Do(req)
defer resp.Body.Close()
```

### 异步操作 (JavaScript)
```javascript
// 并行执行
const results = await Promise.all([
  fetchUser(id),
  fetchPosts(id),
  fetchComments(id)
]);

// 错误处理
const result = await operation().catch(err => ({ error: err.message }));
```

### 数据库操作 (SQL)
```sql
-- 高效分页
SELECT * FROM posts 
WHERE created_at < ?
ORDER BY created_at DESC 
LIMIT 20;

-- 更新插入模式
INSERT INTO users (id, name, email) 
VALUES (?, ?, ?)
ON DUPLICATE KEY UPDATE 
  name = VALUES(name),
  updated_at = NOW();
```

### 状态管理 (React)
```typescript
const useAsyncData = <T>(fetcher: () => Promise<T>) => {
  const [state, setState] = useState<{
    data: T | null;
    loading: boolean;
    error: string | null;
  }>({ data: null, loading: true, error: null });

  useEffect(() => {
    fetcher()
      .then(data => setState({ data, loading: false, error: null }))
      .catch(err => setState({ data: null, loading: false, error: err.message }));
  }, []);

  return state;
};
```

## 性能优化

### 数据库索引
```sql
-- 常用查询模式的复合索引
CREATE INDEX idx_user_posts ON posts(user_id, created_at DESC);
CREATE INDEX idx_search ON posts(title, content) USING GIN; -- PostgreSQL
```

### 缓存策略
```typescript
// 带TTL的内存缓存
class Cache<T> {
  private data = new Map<string, { value: T; expires: number }>();
  
  set(key: string, value: T, ttlMs: number) {
    this.data.set(key, { value, expires: Date.now() + ttlMs });
  }
  
  get(key: string): T | null {
    const item = this.data.get(key);
    return item && item.expires > Date.now() ? item.value : null;
  }
}
```

### API限流
```javascript
const rateLimit = new Map();
const WINDOW_MS = 60000; // 1分钟
const MAX_REQUESTS = 100;

function checkRate(clientId) {
  const now = Date.now();
  const windowStart = now - WINDOW_MS;
  
  if (!rateLimit.has(clientId)) {
    rateLimit.set(clientId, []);
  }
  
  const requests = rateLimit.get(clientId).filter(time => time > windowStart);
  requests.push(now);
  rateLimit.set(clientId, requests);
  
  return requests.length <= MAX_REQUESTS;
}
```

## 安全实现

### 输入净化
```typescript
import DOMPurify from 'dompurify';
import { z } from 'zod';

const sanitizeHtml = (html: string) => DOMPurify.sanitize(html);
const validateInput = z.string().min(1).max(1000).safeParse;
```

### JWT实现
```go
func generateJWT(userID string) (string, error) {
    token := jwt.NewWithClaims(jwt.SigningMethodHS256, jwt.MapClaims{
        "user_id": userID,
        "exp":     time.Now().Add(time.Hour * 24).Unix(),
        "iat":     time.Now().Unix(),
    })
    return token.SignedString([]byte(secret))
}
```

## 测试工具

### Mock工厂
```javascript
const createMockUser = (overrides = {}) => ({
  id: 'user-123',
  name: 'Test User',
  email: 'test@example.com',
  createdAt: new Date('2024-01-01'),
  ...overrides
});
```

### 数据库测试设置
```go
func setupTestDB() *sql.DB {
    db, _ := sql.Open("sqlite3", ":memory:")
    // 运行迁移
    return db
}

func teardownTestDB(db *sql.DB) {
    db.Close()
}
```

## 部署模式

### Docker多阶段构建
```dockerfile
FROM node:18-alpine AS builder
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production

FROM node:18-alpine AS runtime  
WORKDIR /app
COPY --from=builder /app/node_modules ./node_modules
COPY . .
EXPOSE 3000
CMD ["node", "server.js"]
```

### 健康检查
```go
func healthCheck(w http.ResponseWriter, r *http.Request) {
    checks := map[string]string{
        "database": checkDB(),
        "redis":    checkRedis(),
        "external": checkExternalAPI(),
    }
    
    allHealthy := true
    for _, status := range checks {
        if status != "ok" {
            allHealthy = false
            break
        }
    }
    
    if allHealthy {
        w.WriteHeader(http.StatusOK)
    } else {
        w.WriteHeader(http.StatusServiceUnavailable)
    }
    json.NewEncoder(w).Encode(checks)
}
```