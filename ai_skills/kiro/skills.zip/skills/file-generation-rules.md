---
name: 文件生成规则
description: 严格控制文件生成行为，避免创建不必要的文档和示例文件
version: 1.0.0
author: Kiro Team
tags: [rules, constraints, file-generation]
priority: 1
---

# 文件生成规则

## 核心原则

**只生成用户明确要求的文件，不主动创建文档、示例、测试脚本等辅助文件。**

## 禁止列表（默认不生成）

### ❌ 文档类文件
- README.md、README_*.md
- CHANGELOG.md、HISTORY.md
- CONTRIBUTING.md、CODE_OF_CONDUCT.md
- 任何 .md 文件（除非用户明确要求）
- 文档、说明、指南、手册、教程类文件
- API文档（除非用户明确要求）
- 总结文档（SUMMARY.md、*_SUMMARY.md）

### ❌ 测试相关文件
- 测试脚本：*.sh、*.bat、test_*.sh、run_test.*
- 测试文件：*_test.go、*_test.py、*.test.js
- 测试配置：test_config.*、testing.*

### ❌ 示例和演示文件
- example_*、*_example.*
- demo_*、*_demo.*
- sample_*、*_sample.*
- tutorial_*、*_tutorial.*

### ❌ 配置示例文件
- config_example.*、*_example.yaml
- *.example.json、*.sample.conf
- template_*、*_template.*

### ❌ 快速脚本和工具
- quick_*、easy_*
- setup.sh、install.sh（除非用户明确要求）
- build.sh、deploy.sh（除非用户明确要求）

### ❌ 其他辅助文件
- TODO.md、NOTES.md
- LICENSE、AUTHORS
- .gitignore、.dockerignore（除非用户明确要求）

## 允许生成条件

### ✅ 明确的文件名
用户消息中明确包含完整文件名：
- "创建 README.md"
- "生成 test_user.sh"
- "写一个 example_api.go"

### ✅ 明确的生成意图
用户消息中明确表达生成意图：
- "生成文档"、"写文档"、"创建文档"
- "写README"、"生成README"
- "创建测试脚本"、"写测试脚本"
- "写个demo"、"创建示例"、"生成示例代码"
- "生成配置示例"、"创建配置模板"

### ✅ 核心业务代码（始终允许）
- 业务逻辑代码（service.go、handler.go、model.go等）
- API路由文件（router.go）
- 数据模型（models/*.go）
- DTO定义（dto/*.go）
- 数据库迁移脚本（migration_*.sql）
- 配置文件（config.yaml、仅当必需时）

## 判断流程

```
用户请求 → 是否是核心业务代码？
           ├─ 是 → 直接生成
           └─ 否 → 是否在禁止列表？
                   ├─ 是 → 用户是否明确要求？
                   │       ├─ 是 → 生成
                   │       └─ 否 → 不生成，不提及
                   └─ 否 → 生成
```

## 实施细则

### 1. 完成任务后
- ✅ 简短说明完成了什么（1-2句话）
- ❌ 不要创建总结文档
- ❌ 不要创建README
- ❌ 不要创建测试脚本
- ❌ 不要询问是否需要文档

### 2. 实现新功能时
- ✅ 只生成必需的业务代码
- ✅ 更新现有的SQL schema文件
- ✅ 创建必要的迁移脚本
- ❌ 不要创建API文档（除非用户要求）
- ❌ 不要创建使用示例
- ❌ 不要创建测试文件

### 3. 响应用户时
- ✅ 直接完成任务
- ✅ 简短确认完成
- ❌ 不要主动提供"我还可以帮你..."
- ❌ 不要询问"是否需要文档/测试/示例"
- ❌ 不要建议创建额外文件

## 示例场景

### ❌ 错误做法
```
用户：实现用户注销功能
AI：
1. 创建业务代码 ✓
2. 创建 USER_DEACTIVATE_SUMMARY.md ✗
3. 创建 docs/api/user-deactivate-api.md ✗
4. 询问是否需要测试脚本 ✗
```

### ✅ 正确做法
```
用户：实现用户注销功能
AI：
1. 更新 User 模型添加 DeletedAt 字段
2. 创建 DeactivateAccount API
3. 更新 SQL schema
4. 创建迁移脚本
完成。用户注销功能已实现。
```

### ✅ 用户明确要求时
```
用户：实现用户注销功能，并生成API文档
AI：
1. 创建业务代码
2. 创建 docs/api/user-deactivate-api.md ✓（用户明确要求）
```

## 特殊说明

### 数据库相关
- ✅ 始终更新 docs/sql/mysql_schema.sql（核心schema）
- ✅ 创建 docs/sql/migration_*.sql（必需的迁移脚本）
- ❌ 不创建 docs/sql/README.md（除非用户要求）

### 代码注释
- ✅ 在代码中添加必要的注释
- ✅ 添加Swagger注释（用于API文档生成）
- ❌ 不创建单独的文档文件

### 项目初始化
- 即使是新项目，也不主动创建README.md
- 只在用户明确要求时创建

## 违规检查清单

在生成任何文件前，检查：
- [ ] 这是核心业务代码吗？
- [ ] 这是用户明确要求的吗？
- [ ] 文件名包含 example、demo、sample、test、readme 等吗？
- [ ] 这是 .md 文件吗？
- [ ] 这是测试脚本吗？

如果不是核心业务代码且用户未明确要求，则不生成。

---

**记住：少即是多。只生成必需的代码，不创建"可能有用"的文件。**
